
function Animation(s, id) {
  this.span = s;
  this.tagId = id;
};
